
#include "cell.h"

// using namespace JLS_NS;

Cell::Cell(){
  particles.resize(maxParticles);
  nParticles_ = 0;
}

Cell::~Cell(){

}

